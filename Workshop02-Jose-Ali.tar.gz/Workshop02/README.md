<p align="center">
  <a href="http://nestjs.com/" target="blank"><img src="https://nestjs.com/img/logo-small.svg" width="200" alt="Nest Logo" /></a>
</p>

[<- Workshop 1](../Workshop01/README.md)

# Workshop 2

[1. Agregar entradas en hosts maquina anfitriona ->](./agregar-entradas-hosts.md)

[2. Instalar paquetes para servidor LAMP en maquina virtual ->](./instalar-lamp.md)

[3. Crear el archivo VHOST ->](./create-vhosts-file.md)


